// Package cluster implements DBScan clustering on (lat, lon) using K-D Tree
package cluster

import (
	"datastream/controller/clustering"
)

// Point is longitue, latittude
type Point clustering.Point

// Assign tow point
func (p1 Point) Assign(p2 Point) {
	for key, val := range p2 {
		var v = val
		p1[key] = v
	}
}
func (p1 Point) toFloat() *[]float64 {
	rp := make([]float64, len(p1))
	i := 0
	for k, v := range p1 {
		switch p1[k].(type) {
		case float64:
			rp[i] = v.(float64)
		case int:
			rp[i] = float64(v.(int))
		}
		i++

	}
	return &rp
}

// Pow2 point
func (p1 Point) Pow2() *Point {
	rp := make(Point)
	rp.Assign(p1)
	// rp := p1
	for k, v := range p1 {
		switch rp[k].(type) {
		case float64:
			rp[k] = v.(float64) * v.(float64)
		case int:
			rp[k] = v.(int) * v.(int)
		}

	}
	return &rp
}

// Add tow point
func (p1 Point) Add(newP Point) *Point {
	rp := make(Point)
	rp.Assign(p1)
	// rp := p1
	for k, v := range p1 {
		switch rp[k].(type) {
		case float64:
			switch newP[k].(type) {
			case float64:
				rp[k] = v.(float64) + newP[k].(float64)
			case int:
				rp[k] = v.(float64) + float64(newP[k].(int))
			case string:
				//
			}
		case int:
			switch newP[k].(type) {
			case float64:
				rp[k] = float64(v.(int)) + newP[k].(float64)
			case int:
				rp[k] = v.(int) + newP[k].(int)
			case string:
				//
			}
		case string:
			//
		}
	}
	return &rp
}

// Sub tow point
func (p1 Point) Sub(newP Point) *Point {
	rp := make(Point)
	rp.Assign(p1)
	// rp := p1
	for k, v := range p1 {
		switch rp[k].(type) {
		case float64:
			switch newP[k].(type) {
			case float64:
				rp[k] = v.(float64) - newP[k].(float64)
			case int:
				rp[k] = v.(float64) - float64(newP[k].(int))
			case string:
				//
			}
		case int:
			switch newP[k].(type) {
			case float64:
				rp[k] = float64(v.(int)) - newP[k].(float64)
			case int:
				rp[k] = v.(int) - newP[k].(int)
			case string:
				//
			}
		case string:
			//
		}
	}
	return &rp
}

// Mult tow point
func (p1 Point) Mult(z float64) *Point {
	rp := make(Point)
	rp.Assign(p1)
	// rp := p1
	for k, v := range p1 {
		switch rp[k].(type) {
		case float64:
			rp[k] = v.(float64) * z
		case int:
			rp[k] = z * float64(v.(int))
		case string:
			//
		}
	}
	return &rp
}

// MultP tow point
func (p1 Point) MultP(newP Point) *Point {
	rp := make(Point)
	rp.Assign(p1)
	// rp := p1
	for k, v := range p1 {
		switch rp[k].(type) {
		case float64:
			switch newP[k].(type) {
			case float64:
				rp[k] = v.(float64) * newP[k].(float64)
			case int:
				rp[k] = v.(float64) * float64(newP[k].(int))
			case string:
				//
			}
		case int:
			switch newP[k].(type) {
			case float64:
				rp[k] = float64(v.(int)) * newP[k].(float64)
			case int:
				rp[k] = v.(int) * newP[k].(int)
			case string:
				//
			}
		case string:
			//
		}
	}
	return &rp
}

// PointList is a slice of Points
type PointList []Point

// Cluster is a result of DBScan work
type Cluster struct {
	C      int
	Points []Point
}

// sqDist returns squared (w/o sqrt & normalization) distance between two points
func (a *Point) sqDist(b *Point) float64 {
	return DistanceSphericalFast(a, b)
}

// LessEq - a <= b
func (a Point) LessEq(b Point) bool {
	for k, v := range b {
		if a[k].(float64) > v.(float64) {
			return false
		}
	}
	return true
}

// GreaterEq - a >= b
func (a Point) GreaterEq(b Point) bool {
	for k, v := range b {
		if a[k].(float64) < v.(float64) {
			return false
		}
	}
	return true
}

// CentroidAndBounds calculates center and cluster bounds
func (c Cluster) CentroidAndBounds(points PointList) (center, min, max Point) {
	if len(c.Points) == 0 {
		panic("empty cluster")
	}

	min = c.Points[0]
	max = c.Points[0]
	center = c.Points[0]
	for i := 1; i < len(c.Points); i++ {
		pt := points[i]
		center.Add(pt)

		if !pt.GreaterEq(min) {
			min.Assign(pt)
		}
		if !pt.LessEq(max) {
			max.Assign(pt)
		}

	}
	center.Mult(float64(len(c.Points)))

	return
}

// Inside checks if (innerMin, innerMax) rectangle is inside (outerMin, outMax) rectangle
func Inside(innerMin, innerMax, outerMin, outerMax *Point) bool {
	return innerMin.GreaterEq(*outerMin) && innerMax.LessEq(*outerMax)
}
